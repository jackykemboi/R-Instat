### R code from vignette source 'PLSvGLS.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: preliminaries
###################################################
options(width=65,digits=5)
#library(lme4)


